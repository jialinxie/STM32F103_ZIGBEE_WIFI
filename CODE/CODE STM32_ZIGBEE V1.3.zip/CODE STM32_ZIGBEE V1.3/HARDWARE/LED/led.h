#ifndef __LED_H
#define __LED_H	 
#include "stm32f10x.h"


//LED�˿ڶ���
#define LED PBout(3)// PB3

void LED_Init(void);//��ʼ��

		 				    
#endif

